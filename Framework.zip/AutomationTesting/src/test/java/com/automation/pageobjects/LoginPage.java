package com.automation.pageobjects;

import java.util.List;

import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.automation.config.LocalDriverManager;
import com.automation.constants.Constants;
import com.automation.exception.AutomationException;
import com.automation.utils.DriverUtilsImpl;
import com.automation.utils.PropertyUtils;
import com.automation.utils.TestResultsUtils;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindAll;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.iOSXCUITBy;
import io.appium.java_client.pagefactory.AndroidBy;

public class LoginPage extends DriverUtilsImpl{
	
	TestResultsUtils testResultUtilities = new TestResultsUtils();
	AppiumDriver driver;
	public LoginPage(AppiumDriver driver){
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSXCUITFindBy(accessibility = "")
	@AndroidFindBy(accessibility = "test-Username")
	private MobileElement username;
	
	
	@iOSXCUITFindBy(accessibility = "")
	@AndroidFindBy(accessibility = "test-Password")
	private MobileElement pswd;
	
	@iOSXCUITFindBy(xpath = "")
	@AndroidFindBy(accessibility = "test-LOGIN")
	private MobileElement loginBtn;
	
	
	@iOSXCUITFindAll(value = {@iOSXCUITBy(xpath="//*[@name='12']")})
	@AndroidFindAll(value = {@AndroidBy(xpath="//*[@tagname='as']")})
	private List<MobileElement> listObjects;
//	
	public void loginApp() throws Exception{
	
		username.sendKeys("krishnaappium@mailinator.com");
		pswd.sendKeys("test1234");
		loginBtn.click();
		testResultUtilities.logger.log(LogStatus.PASS, "successfully entered credentrails");		
		
	}
	
}
