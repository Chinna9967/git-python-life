package com.automation.pageobjects;

public class DashboardPage {

}
