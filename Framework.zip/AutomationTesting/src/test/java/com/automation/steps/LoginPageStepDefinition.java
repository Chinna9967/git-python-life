package com.automation.steps;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automation.config.LocalDriverManager;
import com.automation.config.AppiumNGSuite;
import com.automation.exception.AutomationException;
import com.automation.pageobjects.LoginPage;
import com.automation.utils.DriverUtilsImpl;
import com.automation.utils.LocalTestDataManager;
//import com.automation.utils.DriverUtilsImpl;
import com.automation.utils.TestDataUtils;
import com.automation.utils.TestResultsUtils;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;


public class LoginPageStepDefinition extends TestDataUtils{


	DriverUtilsImpl reusablemethods = new DriverUtilsImpl();
	/** The logger. */
	 static  Logger LOG = LoggerFactory.getLogger(LoginPageStepDefinition.class);

	TestResultsUtils testResultUtilities = new TestResultsUtils();

	
		
	  @Given("^user is on the app login screen$")
	    public void user_is_on_the_app_login_screen() throws Throwable {
		  AppiumNGSuite obj = new AppiumNGSuite();
			 obj.setUpSuite("Mobile");
	    }
	 
	 
	  @When("^user enters credentails and click on login button$")
	    public void user_enters_credentails_and_click_on_login_button() throws Throwable {
	        instanceToLoginPage().loginApp();
	    }

	 
	 
	 private LoginPage instanceToLoginPage(){
			LoginPage lp = new LoginPage(LocalDriverManager.getAppiumDriver());
			return lp;
		}
	  
}
