package com.automation.config;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automation.constants.Constants;
import com.automation.exception.*;
import com.automation.utils.PropertyUtils;

/**
 * The Class SeleniumNGSuite.
 */
public class AppiumNGSuite {

	/** The logger. */
	private static final Logger LOG = LoggerFactory.getLogger(AppiumNGSuite.class);

	/** The base project path. */
	public static String baseProjectPath = System.getProperty(Constants.USER_DIR);

	/** The configprops. */
	public static PropertyUtils configprops = new PropertyUtils(baseProjectPath.concat(Constants.CONFIG_PROPERTY));

	/** The browser type. */
	public static String browserType = configprops.getProperty("browser_name");

	/** The url. */
	public static String url = configprops.getProperty(Constants.URL);

	/** The android platform name. */
	public static String androidPlatformName = configprops.getProperty("android_platform_name");
	
	/** The android device name. */
	public static String androidDeviceName = configprops.getProperty("android_device_name");
	
	/** The android platform version. */
	public static String androidPlatformVersion = configprops.getProperty("android_platform_version");
	
	/** The iOS platform name. */
	public static String iOSPlatformName = configprops.getProperty("ios_platform_name");
	
	/** The device name. */
	public static String iOSDeviceName = configprops.getProperty("ios_device_name");
	
	/** The platform version. */
	public static String iOSPlatformVersion = configprops.getProperty("ios_platform_version");
	
	/** The execution OS. */
	public static String executionOperatingSystem = configprops.getProperty("executionOS");
	
	/** The device url. */
	public static String appiumServerURL = configprops.getProperty("server_URL");
	
	
	
	/** The current suite. */
	public static String currentSuite = "";

	/** The creating object to DriverConfig. */
	public DriverConfig config = new DriverConfig();
	
	

	/**
	 * Sets the up suite.
	 *
	 * @throws Throwable
	 *             the throwable
	 */
	public void setUpSuite(String executionMode) throws Throwable {
		switch(executionMode){
			case "Mobile":
				switch(executionOperatingSystem){
				case "Android":
				config.setUp(androidPlatformName,androidPlatformVersion,androidDeviceName,browserType,appiumServerURL);
				break;
				case "iOS":
				config.setUp(iOSPlatformName,iOSPlatformVersion,iOSDeviceName,browserType,appiumServerURL);
				break;	
				
				}
				break;	
		}
		
	}

	/**
	 * Tear down.
	 *
	 */
	public void tearDown() throws AutomationException {

		try {
				LocalDriverManager.getDriver().quit();
			LOG.info("Successfully closed the browser ");
		}catch (Exception exception) {
			LOG.error("Error in closing the browser:: {}", exception.getMessage());
			exception.printStackTrace();
			throw new AutomationException(exception);
		}

	}
	
	
}